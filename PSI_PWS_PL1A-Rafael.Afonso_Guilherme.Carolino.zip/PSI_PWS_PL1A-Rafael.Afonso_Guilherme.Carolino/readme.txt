link: https://github.com/rafael2626/PWS-2022

credenciais de cliente: rafa, pass:123

credenciais de funcionario: miguel, pass:1234

credenciais de administrador: nuno, pass:123