<?php
require_once  'controllers/BaseController.php';
class UserController extends  BaseController
{
}