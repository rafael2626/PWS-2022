<?php

use ActiveRecord\Model;

class Genre extends Model
{

}