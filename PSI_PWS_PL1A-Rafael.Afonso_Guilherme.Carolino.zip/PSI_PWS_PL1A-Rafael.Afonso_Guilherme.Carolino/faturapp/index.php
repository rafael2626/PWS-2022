<?php
require_once './router.php';
require_once 'Controllers/UserController.php';