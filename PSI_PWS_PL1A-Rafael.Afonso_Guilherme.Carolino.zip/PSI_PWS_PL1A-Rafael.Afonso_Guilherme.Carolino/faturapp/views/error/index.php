Ocorreu um erro.
<?php

if($callbackRoute != null)
{
    echo '<a href="' . $callbackRoute . '">Voltar</a>';
}

?>