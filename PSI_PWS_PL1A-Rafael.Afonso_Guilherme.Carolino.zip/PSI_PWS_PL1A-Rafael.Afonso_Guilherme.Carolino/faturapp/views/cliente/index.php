<?php require_once './views/layout/clienteheader.php';
?>
<h2 class="text-left top-space">Cliente Index</h2>
<?php require_once './views/layout/footer.php'; ?>
