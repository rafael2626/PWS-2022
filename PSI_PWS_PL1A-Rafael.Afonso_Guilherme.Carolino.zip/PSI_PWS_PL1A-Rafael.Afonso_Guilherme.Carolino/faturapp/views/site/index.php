<?php require_once './views/layout/header.php'; ?>
<body>
    <div class="container-fluid">
        <div class="row">
            <h1 class="fw-bold text-center">E-Fatura App</h1>
            <a href="./router.php">
                <img src="./public/img/img.jpg" class="img-fluid rounded mx-auto d-block">
            </a>
        </div>
    </div>
</body>
<?php require_once './views/layout/footer.php'; ?>