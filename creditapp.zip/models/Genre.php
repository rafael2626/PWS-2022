<?php

class Genre extends \ActiveRecord\Model
{

}