<?php require_once './views/layout/header.php'; ?>
    <div class="container-fluid">
        <div class="row">
            <h1 class="fw-bold text-center">Creditapp Home</h1>
            <a href="./router.php">
                <img src="./public/img/img.jpg" class="img-fluid rounded mx-auto d-block">
            </a>
        </div>
    </div>
<?php require_once './views/layout/footer.php'; ?>